#include "Menu.h"

SkyboxRender* menuskyboxItem;
ModelRender* menumodelItem;
ShadowMapRender* menushadowItem;

Menu::Menu(unsigned int width, unsigned int height) {
	this->Width = width;
	this->Height = height;
	Camera camera(glm::vec3(0.0, 0.0, 7.0), glm::vec3(0.0, 1.0, 0.0), 90, 0);
    camera.Front = glm::vec3(0.0, 0.0, -1.0);
    pos.push_back(glm::vec3(5.0f, 0.0f, 0.0f));
    pos.push_back(glm::vec3(-5.0f, 0.0f, 0.0f));
    pos.push_back(glm::vec3(0.0f, 0.0f, 5.0f));
    pos.push_back(glm::vec3(0.0f, 0.0f, -5.0f));
}

Menu::~Menu() {

}

void Menu::ProcessInput(float dt)
{
    if (this->Keys[GLFW_KEY_W])
        camera.ProcessKeyboard(FORWARD, dt);
    if (this->Keys[GLFW_KEY_S])
        camera.ProcessKeyboard(BACKWARD, dt);
    if (this->Keys[GLFW_KEY_A])
        camera.ProcessKeyboard(LEFT, dt);
    if (this->Keys[GLFW_KEY_D])
        camera.ProcessKeyboard(RIGHT, dt);
}

void Menu::Init() {
    lightDir = glm::vec3(-1.2f, -1.0f, -2.0f);
    lightPos = glm::vec3(6.0f, 5.0f, 10.0f);
    glEnable(GL_DEPTH_TEST);
    glEnable(GL_FRAMEBUFFER_SRGB);
    //Load Skybox
    ResourceManager::LoadShader("skybox.vs", "skybox.fs", nullptr, "skyboxShader");
    // -------------------------------------------------------
    ResourceManager::LoadShader("glider.vs", "glider.fs", nullptr, "gliderShader");

    //Load Skybox texture
    std::vector<std::string> faces;
    faces.push_back(std::string("resources/skybox/menu/right.png"));
    faces.push_back(std::string("resources/skybox/menu/left.png"));
    faces.push_back(std::string("resources/skybox/menu/top.png"));
    faces.push_back(std::string("resources/skybox/menu/bottom.png"));
    faces.push_back(std::string("resources/skybox/menu/front.png"));
    faces.push_back(std::string("resources/skybox/menu/back.png"));
    menuskyboxItem = new SkyboxRender(ResourceManager::GetShader("skyboxShader"), faces);

    //Load ShadowMap
    menushadowItem = new ShadowMapRender(ResourceManager::GetShader("shadowShader"), lightPos, Width, Height);

    //Load all model
    menumodelItem = new ModelRender(ResourceManager::GetShader("gliderShader"), lightDir, lightPos);
    menumodelItem->addModel("resources/objects/glider1/glider1.obj", "glider1");
    menumodelItem = new ModelRender(ResourceManager::GetShader("gliderShader"), lightDir, lightPos);
    menumodelItem->addModel("resources/objects/glider2/glider2.obj", "glider2");
    menumodelItem = new ModelRender(ResourceManager::GetShader("gliderShader"), lightDir, lightPos);
    menumodelItem->addModel("resources/objects/glider3/model.obj", "glider3");
    menumodelItem = new ModelRender(ResourceManager::GetShader("gliderShader"), lightDir, lightPos);
    menumodelItem->addModel("resources/objects/glider4/glider4.obj", "glider4");
}

void Menu::Render() {
    //���Ȼ���shadowmap
    glm::mat4 projection = glm::perspective(glm::radians(camera.Zoom), (float)Width / (float)Height, 0.1f, 100.0f);
    glm::mat4 view = camera.GetViewMatrix();
    glm::mat4 model = glm::mat4(1.0f);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    //���� glider
    projection = glm::perspective(glm::radians(camera.Zoom), (float)Width / (float)Height, 0.1f, 100.0f);
    view = camera.GetViewMatrix();
    model = glm::mat4(1.0f);
    model = glm::translate(model, pos[0]);
    model = glm::scale(model, glm::vec3(1.0f, 1.0f, 1.0f));
    model = glm::rotate(model, glm::radians(180.0f), glm::vec3(0.0f, 1.0f, 0.0f));
    menumodelItem->drawModel("glider1", model, view, projection, camera.Position, menushadowItem);

    projection = glm::perspective(glm::radians(camera.Zoom), (float)Width / (float)Height, 0.1f, 100.0f);
    view = camera.GetViewMatrix();
    model = glm::mat4(1.0f);
    model = glm::translate(model, pos[1]);
    model = glm::scale(model, glm::vec3(1.0f, 1.0f, 1.0f));
    model = glm::rotate(model, glm::radians(180.0f), glm::vec3(0.0f, 1.0f, 0.0f));
    menumodelItem->drawModel("glider2", model, view, projection, camera.Position, menushadowItem);

    projection = glm::perspective(glm::radians(camera.Zoom), (float)Width / (float)Height, 0.1f, 100.0f);
    view = camera.GetViewMatrix();
    model = glm::mat4(1.0f);
    model = glm::translate(model, pos[2]);
    model = glm::scale(model, glm::vec3(1.0f, 1.0f, 1.0f));
    model = glm::rotate(model, glm::radians(180.0f), glm::vec3(0.0f, 1.0f, 0.0f));
    menumodelItem->drawModel("glider3", model, view, projection, camera.Position, menushadowItem);

    projection = glm::perspective(glm::radians(camera.Zoom), (float)Width / (float)Height, 0.1f, 100.0f);
    view = camera.GetViewMatrix();
    model = glm::mat4(1.0f);
    model = glm::translate(model, pos[3]);
    model = glm::scale(model, glm::vec3(1.0f, 1.0f, 1.0f));
    model = glm::rotate(model, glm::radians(180.0f), glm::vec3(0.0f, 1.0f, 0.0f));
    menumodelItem->drawModel("glider4", model, view, projection, camera.Position, menushadowItem);

    //�����Ⱦ��պ�
    projection = glm::perspective(glm::radians(camera.Zoom), (float)Width / (float)Height, 0.1f, 100.0f);
    view = glm::mat4(glm::mat3(camera.GetViewMatrix()));
    menuskyboxItem->drawSkyBox(view, projection);
}
