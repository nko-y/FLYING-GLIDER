#ifndef SPRITE_RENDERER_H
#define SPRITE_RENDERER_H

#include <glad/glad.h>
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>

#include <map>
#include <string>

#include "texture.h"
#include "shader.h"

class SpriteRender
{
public:
	SpriteRender(Shader shader);
	~SpriteRender();
	void addTexture(Texture2D oneTexture, std::string name);
	void drawSprite(glm::mat4 model, glm::mat4 view, glm::mat4 projection, glm::vec3 cameraPos);
private:
	Shader shader;
	unsigned int quadVAO;
	std::map<std::string, Texture2D> allTextures;
};

#endif
