#ifndef MENU_H
#define MENU_H

#include <glad/glad.h>
#include <GLFW/glfw3.h>
#include <iostream>
#include <vector>
#include <string>

#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>

#include <camera.h>
#include <shader.h>

#include "resource_manager.h"
#include "skyboxrender.h"
#include "modelrender.h"


class Menu
{
public:
	vector<glm::vec3> pos;
	unsigned int Width, Height;
	bool Keys[1024];
	bool KeysProcessed[1024];
	Camera camera;
	glm::vec3 lightDir;
	glm::vec3 lightPos;

	Menu(unsigned int width, unsigned int height);
	~Menu();

	void Init();
	void ProcessInput(float dt);
	//void Update(float dt);
	void Render();

};

#endif